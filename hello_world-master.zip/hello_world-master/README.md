# hello_world

A samle repository for a classroom assignment, to help students learn Github commands
