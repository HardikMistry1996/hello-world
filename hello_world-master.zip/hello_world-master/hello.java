// a simple program to practice common Github commands 

public class hello {

    public static void main(String [] args) {


        String firstName = "Elizabeth";
        String lastName = "Jones";
	
        System.out.println("Hello Class!");



    }
}


`
